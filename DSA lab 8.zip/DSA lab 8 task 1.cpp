#include <iostream>

using namespace std;
class Node {
public:
    string title;
    double price;
    int edition;
    int pages;
    
   Node() {}
    Node(string t, double p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
    }
};

class BookStack {
private:
    Node books[5];
    int top;
    
public:
    BookStack() {
        top = -1;
    }
    
    void push(Node book) {
        if (top >= 5 - 1) {
            cout << "Stack overflow!" << endl;
            return;
        }
        books[++top] = book;
    }
    
    void pop() {
        if (isEmpty()) {
            cout << "Stack underflow!" << endl;
            return;
        }
        top--;
    }
    
    Node peek() {
        if (isEmpty()) {
            cout << "Stack is empty!" << endl;
            return Node();
        }
        return books[top];
    }
    
    void display() {
        if (isEmpty()) {
            cout << "Stack is empty!" << endl;
            return;
        }
        cout << "Books in stack (top to bottom):" << endl;
        for (int i = top; i >= 0; i--) {
            cout << "Title: " << books[i].title << ", Price: $" << books[i].price 
                 << ", Edition: " << books[i].edition << ", Pages: " << books[i].pages << endl;
        }
    }
    
    bool isEmpty() {
        return top == -1;
    }
};

int main() {
    BookStack stack;
    
   
    stack.push(Node("Software Engineering", 12.99, 3, 218));
    stack.push(Node("Discrete Structure", 10.50, 2, 281));
    stack.push(Node("Calculus", 9.99, 1, 328));
    stack.push(Node("Data structure", 8.75, 4, 279));
    stack.push(Node("Islamic studies", 15.25, 5, 310));
    

    Node topBook = stack.peek();
    cout << "Top book: " << topBook.title << endl << endl;
    
    stack.pop();
    stack.pop();
    
    
    stack.display();
    return 0;
}