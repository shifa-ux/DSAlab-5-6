#include <iostream>
using namespace std;

// Define structure for Applicant node
struct Applicant {
    int applicant_id;
    float height, weight, eyesight;
    bool test_done;
    Applicant* next;
};

Applicant *front = NULL, *rear = NULL;

void enqueue(int id, float h, float w, float e, bool done) {
    Applicant* temp = new Applicant{id, h, w, e, done, NULL};
    if (rear == NULL) {
        front = rear = temp;
    } else {
        rear->next = temp;
        rear = temp;
    }
}

void dequeue() {
    if (front == NULL) return;
    Applicant* temp = front;
    front = front->next;
    delete temp;
    if (front == NULL) rear = NULL;
}


void removeSecond() {

    if (front == NULL || front->next == NULL) {
        return;
    }

    Applicant* second = front->next;

    front->next = second->next;
    if (second == rear) {
        rear = front;
    }
    delete second;
}



void display() {
    Applicant* temp = front;
    while (temp != NULL) {
        cout << "ID: " << temp->applicant_id << ", Height: " << temp->height
             << ", Weight: " << temp->weight << ", Eyesight: " << temp->eyesight
             << ", Test Done: " << (temp->test_done ? "Yes" : "No") << endl;
        temp = temp->next;
    }
}

int main() {
    // Add 7 applicants
    for (int i = 1; i <= 7; i++) {
        enqueue(i, 170 + i, 60 + i, 6.0 + i * 0.1, false);
    }

    cout << "\nInitial Queue:\n";
    display();

    cout << "\nRemoving 2nd applicant (urgency case)...\n";
    removeSecond();

    cout << "\nQueue after removing 2nd applicant:\n";
    display();

    cout << "\nRemoving front applicant (test done)...\n";
    dequeue();

    cout << "\nQueue after test completed by front applicant:\n";
    display();

    return 0;
}

