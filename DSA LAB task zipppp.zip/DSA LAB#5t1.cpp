#include <iostream>
using namespace std;

class Node {
public:
    double rainfall;
    Node* next;
    Node* prev;
};

class DoublyLinkedList {
private:
    Node* head;
    Node* tail;
    int size;
public:
    DoublyLinkedList() {
        head = nullptr;
        tail = nullptr;
        size = 0;
    }

    void append(double rainfall) {
        if (rainfall < 0) {
            cout << "Invalid input: Rainfall cannot be negative." << endl;
            return;
        }

        Node* newNode = new Node();
        newNode->rainfall = rainfall;
        newNode->next = nullptr;

        if (head == nullptr) {
            head = newNode;
            tail = newNode;
            newNode->prev = nullptr;
        }
        else {
            newNode->prev = tail;
            tail->next = newNode;
            tail = newNode;
        }
        size++;
    }

    double calculateTotalRainfall() {
        double totalRainfall = 0;
        Node* current = head;
        while (current != nullptr) {
            totalRainfall += current->rainfall;
            current = current->next;
        }
        return totalRainfall;
    }

    double calculateAverageRainfall() {
        if (size == 0) {
            return 0;
        }
        return calculateTotalRainfall() / size;
    }

    void findHighestAndLowestRainfall(int& highestDay, int& lowestDay) {
        if (size == 0) {
            highestDay = -1;
            lowestDay = -1;
            return;
        }

        double highestRainfall = head->rainfall;
        double lowestRainfall = head->rainfall;
        highestDay = 1;
        lowestDay = 1;
        Node* current = head;
        int day = 1;

        while (current != nullptr) {
            if (current->rainfall > highestRainfall) {
                highestRainfall = current->rainfall;
                highestDay = day;
            }
            else if (current->rainfall < lowestRainfall) {
                lowestRainfall = current->rainfall;
                lowestDay = day;
            }
            current = current->next;
            day++;
        }
    }

    double findRainfallAfter5thNode() {
        if (size < 6) {
            return -1;
        }

        Node* current = head;
        for (int i = 0; i < 5; i++) {
            current = current->next;
        }

        return current->next->rainfall;
    }
};

int main() {
    DoublyLinkedList dll;

    for (int i = 0; i < 7; i++) {
        double rainfall;
        while (true) {
            cout << "Enter rainfall for day " << i + 1 << ": ";
            cin >> rainfall;
            if (rainfall >= 0) {
                dll.append(rainfall);
                break;
            }
            else {
                cout << "Invalid input. Please enter a non-negative number." << endl;
            }
        }
    }

    double totalRainfall = dll.calculateTotalRainfall();
    double averageRainfall = dll.calculateAverageRainfall();
    int highestDay, lowestDay;
    dll.findHighestAndLowestRainfall(highestDay, lowestDay);
    double rainfallAfter5thNode = dll.findRainfallAfter5thNode();

    cout << "Total rainfall: " << totalRainfall << endl;
    cout << "Average rainfall: " << averageRainfall << endl;
    cout << "Highest rainfall on day: " << highestDay << endl;
    cout << "Lowest rainfall on day: " << lowestDay << endl;
    cout << "Rainfall after 5th node: " << rainfallAfter5thNode << endl;
    return 0;

}