#include <iostream>
#include <string>
using namespace std;

struct Player {
    string name;
    int score;
    Player* next;
    Player* prev;
};

class GolfTournament {
private:
    Player* head;

public:
    GolfTournament() : head(NULL) {}
    Player* createPlayer(const string& name, int score) {
        Player* newPlayer = new Player();
        newPlayer->name = name;
        newPlayer->score = score;
        newPlayer->next = NULL;
        newPlayer->prev = NULL;
        return newPlayer;
    }
    void addPlayer(const string& name, int score) {
        Player* newPlayer = createPlayer(name, score);
        if (head == NULL) {
            head = newPlayer;
            return;
        }
        Player* current = head;
        while (current != NULL && current->score < score) {
            current = current->next;
        }

        if (current == head) { 
            newPlayer->next = head;
            head->prev = newPlayer;
            head = newPlayer;
        } else if (current == NULL) { 
            Player* last = head;
            while (last->next != NULL) {
                last = last->next;
            }
            last->next = newPlayer;
            newPlayer->prev = last;
        } else { 
            newPlayer->next = current;
            newPlayer->prev = current->prev;
            current->prev->next = newPlayer;
            current->prev = newPlayer;
        }
    }
    void displayList() {
        Player* current = head;
        while (current != NULL) {
            cout << current->name << " - " << current->score << endl;
            current = current->next;
        }
    }
    void displayLowestScore() {
        if (head == NULL) {
            cout << "No players in the tournament." << endl;
            return;
        }
        Player* current = head;
        while (current->next != NULL) {
            current = current->next;
        }
        cout << "Player with the lowest score: " << current->name << " - " << current->score << endl;
    }

    void displayPlayersWithSameScore(const string& name) {
        Player* current = head;
        int targetScore = -1;

        while (current != NULL) {
            if (current->name == name) {
                targetScore = current->score;
                break;
            }
            current = current->next;
        }

        if (targetScore == -1) {
            cout << "Player not found." << endl;
            return;
        }

        current = head;
        cout << "Players with the same score (" << targetScore << "):" << endl;
        while (current != NULL) {
            if (current->score == targetScore) {
                cout << current->name << " - " << current->score << endl;
            }
            current = current->next;
        }
    }
    void displayBackwardFromPlayer(const string& name) {
        Player* current = head;

        while (current != NULL) {
            if (current->name == name) {
                break;
            }
            current = current->next;
        }

        if (current == NULL) {
            cout << "Player not found." << endl;
            return;
        }

        cout << "Players behind " << name << ":" << endl;
        while (current->prev != NULL) {
            current = current->prev;
            cout << current->name << " - " << current->score << endl;
        }
    }

    ~GolfTournament() {
        Player* current = head;
        while (current != NULL) {
            Player* next = current->next;
            delete current;
            current = next;
        }
    }
};

int main() {
    GolfTournament tournament;
    int choice;
    string name;
    int score;

    do {
        cout << "\nGolf Tournament Menu:\n";
        cout << "1. Add Player\n";
        cout << "2. Display All Players\n";
        cout << "3. Display Player with Lowest Score\n";
        cout << "4. Display Players with Same Score\n";
        cout << "5. Display Players Backward from a Player\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter player's name: ";
                cin >> name;
                cout << "Enter player's score: ";
                cin >> score;
                tournament.addPlayer(name, score);
                break;

            case 2:
                cout << "All Players:\n";
                tournament.displayList();
                break;

            case 3:
                tournament.displayLowestScore();
                break;

            case 4:
                cout << "Enter player's name to find players with the same score: ";
                cin >> name;
                tournament.displayPlayersWithSameScore(name);
                break;

            case 5:
                cout << "Enter player's name to display players backward from: ";
                cin >> name;
                tournament.displayBackwardFromPlayer(name);
                break;

            case 6:
                cout << "Exiting the program.\n";
                break;

            default:
                cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 6);

    return 0;
}